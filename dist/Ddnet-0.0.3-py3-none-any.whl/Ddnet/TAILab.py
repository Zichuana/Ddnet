# TAILab Main
import pandas as pd
import numpy as np

def info():
    print('TAILab = T.+AI+Lab. TAILab is planned to be a model training lite platform. TAILab address:https://share.streamlit.io/tqthooo2021/tai-lab/main/labmain.py')