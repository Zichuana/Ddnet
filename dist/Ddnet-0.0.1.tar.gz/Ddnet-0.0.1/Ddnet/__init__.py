from __future__ import absolute_import
from .TAILab import *
name = "Ddnet"