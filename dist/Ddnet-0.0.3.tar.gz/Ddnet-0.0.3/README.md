> This is a test. This project is not very useful!!!  
> If you notice it carelessly, you can ignore it!!!  
  
I will continue to update my common functions for model visualization here, which means that **not all content is original**, and this project is mainly convenient for my own use. And **I will learn by writing this library**.  
What is currently included:  
`draw_features`  
Call this method to draw a visual image of a specific layer. There are use cases in my blog: [https://zichuana.github.io/2023/02/10/RepVGGview/](https://zichuana.github.io/2023/02/10/RepVGGview/)  
Note that this blog is written according to the conditions I can read and understand.  
