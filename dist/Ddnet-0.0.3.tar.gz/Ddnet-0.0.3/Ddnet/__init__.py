from __future__ import absolute_import
from .Ddnet import *
name = "Ddnet"